# TUM Assistant — Unified GUI

A local web app that unifies all TUM student automations into one interface:
**send messages → submit homework → find slides → book rooms**

---

## Quick start

```bash
# 1. Install dependencies
pip install -r requirements.txt
playwright install chromium

# 2. Start the server
python server.py

# 3. Open in browser
open http://localhost:5678
```

On first launch, you'll be taken to **Settings** where you enter your credentials once.  
They are stored securely in your system keychain (macOS Keychain / libsecret / Windows Credential Manager) — never in plaintext.

---

## How login works

The first time any action needs Moodle or TUM Online, the Chromium browser opens, logs in via TUM SSO (Shibboleth), and saves the session cookies to `utils/session.json` (owner-readable only, `chmod 600`).

Every subsequent action reuses those cookies — **you are never asked to log in again** unless the session expires (typically weeks). When you update your credentials in Settings, the session is automatically cleared and re-created on the next action.

---

## Features

### Send message
- **Zulip DM** — fuzzy name matching via Gemini against your Zulip user list
- **Zulip stream** — posts to any subscribed stream / topic
- **Moodle forum** — directly navigates to the post form using the URL from `destinations.json`
- **Assignment comment** — finds the right homework and posts a comment

### Submit homework
- Generates a Deckblatt (cover page) with your name, Matrikelnummer, course, date
- Merges Deckblatt + your PDF using pypdf
- Compresses with Ghostscript if over the size limit (`/ebook` 150dpi quality)
- Uploads directly to the TUM Online submission box

### Find slide
- Indexes lecture PDFs using `nomic-ai/nomic-embed-text-v1` (768-dim embeddings)
- HNSW vector search via Qdrant (local, no Docker needed)
- Shows top matches with score + page preview
- Opens the best match in your system PDF viewer

### Book room
- Navigates TUM Online room search with your date/duration/building filters
- Picks the first available slot and confirms the booking

---

## Re-crawling courses

If you enroll in new courses mid-semester, click **Re-crawl courses** in Settings.  
This runs all three crawlers (Moodle, TUM Online, Zulip) in the background and refreshes `destinations.json`.

---

## Project structure

```
tum_assistant/
├── server.py              ← Flask web server + GUI (start here)
├── main.py                ← original CLI (still works)
├── config.py              ← lazy credential loading
├── send_qa.py             ← message sending logic
├── submit_hw.py           ← homework pipeline
├── slide_search.py        ← vector search
├── book_room.py           ← room booking
├── understand.py          ← Gemini intent parser (used by CLI chat mode)
├── destinations.json      ← crawled course URLs (auto-updated)
├── requirements.txt
├── utils/
│   ├── browser.py         ← Playwright session + SSO login (UPDATED)
│   ├── credentials.py     ← keychain storage
│   └── ai_navigator.py    ← Gemini vision navigator
└── crawlers/
    ├── moodle_crawler.py
    ├── tumonline_crawler.py
    └── zulip_crawler.py
```

---

## Environment variables

Only `GEMINI_API_KEY` is needed as an env var (for intent parsing and name matching).  
You can enter it in the Settings panel — it's written to `.env` automatically.

```
GEMINI_API_KEY=AIza...
```

All other credentials (TUM password, Zulip API key) go into the system keychain via the Settings panel.
