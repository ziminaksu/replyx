#!/bin/bash
# launch.sh — start TUM Assistant GUI
# Usage: bash launch.sh

cd "$(dirname "$0")"

# Load .env if it exists
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

echo ""
echo "  TUM Assistant"
echo "  ─────────────────────────────────────"
echo "  Starting server at http://localhost:5678"
echo "  Press Ctrl+C to stop"
echo ""

# Open browser after 1.5s (works on macOS and Linux with xdg-open)
(sleep 1.5 && (open http://localhost:5678 2>/dev/null || xdg-open http://localhost:5678 2>/dev/null)) &

python server.py
