"""
server.py — TUM Assistant local web server.

Starts a Flask app on http://localhost:5678 that provides a full GUI for:
  • Setup / credential management (stored once in system keychain)
  • Send messages (Zulip DM, Zulip stream, Moodle forum, assignment comment)
  • Submit homework (Deckblatt + merge + compress + upload)
  • Search & index lecture slides (HNSW vector search)
  • Book library rooms

Run:  python server.py
Then open:  http://localhost:5678
"""

import json
import os
import sys
import threading
from pathlib import Path

from flask import Flask, jsonify, render_template_string, request, send_from_directory

BASE_DIR = Path(__file__).parent
app = Flask(__name__, static_folder=str(BASE_DIR / "gui_static"))

# ── helpers ───────────────────────────────────────────────────────────────────

def _creds_ok():
    try:
        from utils.credentials import is_registered
        return is_registered()
    except Exception:
        return False


def _load_destinations():
    p = BASE_DIR / "destinations.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text())


# ── routes — setup ────────────────────────────────────────────────────────────

@app.route("/api/status")
def api_status():
    debug = {}
    try:
        from utils.credentials import _load_profile, _KEYRING_OK, SERVICE, _KEY_TUM_PASS
        p = _load_profile() or {}
        debug["profile_exists"] = bool(p)
        debug["tum_user"]       = bool(p.get("tum_user"))
        debug["student_name"]   = bool(p.get("student_name"))
        debug["matrikelnummer"] = bool(p.get("matrikelnummer"))
        debug["keyring_ok"]     = _KEYRING_OK
        if _KEYRING_OK:
            import keyring as kr
            pw = kr.get_password(SERVICE, _KEY_TUM_PASS)
            debug["keyring_has_pass"] = bool(pw)
        else:
            debug["fallback_pass"] = bool(p.get("_tum_password"))
    except Exception as e:
        debug["exception"] = str(e)
    registered = _creds_ok()
    print(f"[status] registered={registered} debug={debug}", flush=True)
    return jsonify({"registered": registered, "debug": debug})


@app.route("/api/profile")
def api_profile():
    try:
        from utils.credentials import _load_profile
        p = _load_profile() or {}
        # never send secrets
        safe = {k: v for k, v in p.items() if not k.startswith("_") and "password" not in k and "api_key" not in k}
        return jsonify(safe)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/setup", methods=["POST"])
def api_setup():
    """Save credentials from the GUI setup form."""
    data = request.json
    try:
        from utils.credentials import _load_profile, _save_profile, _set_secret
        p = _load_profile() or {}

        p["tum_user"]       = data.get("tum_user", "").strip()
        p["zulip_site"]     = data.get("zulip_site", "https://zulip.cit.tum.de").strip()
        p["zulip_email"]    = data.get("zulip_email", "").strip()
        p["student_name"]   = data.get("student_name", "").strip()
        p["matrikelnummer"] = data.get("matrikelnummer", "").strip()

        if data.get("tum_password"):
            _set_secret("tum_password", data["tum_password"], p)
        if data.get("zulip_api_key"):
            _set_secret("zulip_api_key", data["zulip_api_key"], p)

        # Gemini key goes to .env file
        if data.get("gemini_api_key"):
            _write_env("GEMINI_API_KEY", data["gemini_api_key"])

        _save_profile(p)

        # Reset browser session so next action re-logs in with new creds
        _reset_browser()

        # Verify what actually got stored
        from utils.credentials import is_registered, _load_profile as lp2, _KEYRING_OK, SERVICE, _KEY_TUM_PASS
        p2 = lp2() or {}
        registered = is_registered()
        if _KEYRING_OK:
            import keyring as kr
            pw_stored = bool(kr.get_password(SERVICE, _KEY_TUM_PASS))
        else:
            pw_stored = bool(p2.get("_tum_password"))
        print(f"[setup] saved. profile keys={list(p2.keys())} keyring_ok={_KEYRING_OK} pw_stored={pw_stored} is_registered={registered}", flush=True)

        return jsonify({"ok": True, "is_registered": registered, "pw_stored": pw_stored, "keyring_ok": _KEYRING_OK})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/crawl", methods=["POST"])
def api_crawl():
    """Run all crawlers in a background thread."""
    def _run():
        try:
            from crawlers.moodle_crawler    import run as moodle_run
            from crawlers.tumonline_crawler import run as tumonline_run
            from crawlers.zulip_crawler     import run as zulip_run
            moodle_run()
            tumonline_run()
            zulip_run()
        except Exception as e:
            print(f"[crawl] error: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": "Crawl started in background — check terminal for progress."})


# ── routes — courses / destinations ───────────────────────────────────────────

@app.route("/api/courses")
def api_courses():
    data = _load_destinations()
    courses = [k for k in data.keys() if not k.startswith("_")]
    return jsonify(courses)


@app.route("/api/zulip/streams")
def api_zulip_streams():
    data = _load_destinations()
    streams = [s["name"] for s in data.get("_zulip", {}).get("streams", [])]
    return jsonify(streams)


# ── routes — messaging ────────────────────────────────────────────────────────

@app.route("/api/send", methods=["POST"])
def api_send():
    d = request.json
    def _run():
        from send_qa import send_qa
        send_qa(
            course    = d.get("course"),
            dest_type = d.get("dest_type"),
            message   = d.get("message"),
            person    = d.get("person"),
            stream    = d.get("stream"),
            topic     = d.get("topic", "General"),
            assignment= d.get("assignment"),
            attachment= d.get("attachment"),
        )
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": "Sending in background — check terminal."})


# ── routes — homework ─────────────────────────────────────────────────────────

@app.route("/api/submit_hw", methods=["POST"])
def api_submit_hw():
    d = request.form
    file = request.files.get("hw_pdf")
    if file:
        upload_path = BASE_DIR / "uploads" / file.filename
        upload_path.parent.mkdir(exist_ok=True)
        file.save(upload_path)
        hw_pdf = str(upload_path)
    else:
        hw_pdf = d.get("hw_pdf_path", "")

    add_deckblatt = d.get("add_deckblatt", "true").lower() == "true"
    max_size_kb   = int(d.get("max_size_kb", 8000))

    def _run():
        from submit_hw import submit_hw
        submit_hw(
            course        = d.get("course", ""),
            sheet         = d.get("sheet", ""),
            hw_pdf        = hw_pdf,
            add_deckblatt = add_deckblatt,
            max_size_kb   = max_size_kb,
        )
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": "Submission started — check terminal."})


# ── routes — slides ───────────────────────────────────────────────────────────

@app.route("/api/slide/index", methods=["POST"])
def api_slide_index():
    file = request.files.get("pdf")
    if not file:
        return jsonify({"error": "No PDF uploaded"}), 400
    slides_dir = BASE_DIR / "slides"
    slides_dir.mkdir(exist_ok=True)
    dest = slides_dir / file.filename
    file.save(dest)
    def _run():
        from slide_search import index_pdf
        index_pdf(str(dest))
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": f"Indexing {file.filename} in background."})


@app.route("/api/slide/search")
def api_slide_search():
    query = request.args.get("q", "")
    top_k = int(request.args.get("k", 5))
    if not query:
        return jsonify([])
    try:
        from slide_search import search
        results = search(query, top_k=top_k, open_best=False)
        return jsonify(results)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── routes — room booking ─────────────────────────────────────────────────────

@app.route("/api/book_room", methods=["POST"])
def api_book_room():
    d = request.json
    def _run():
        from book_room import book_room
        book_room(d.get("date"), int(d.get("duration", 2)), building=d.get("building"))
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": "Room booking started — check terminal."})


# ── main HTML page ────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template_string(HTML)


# ── utilities ─────────────────────────────────────────────────────────────────

def _reset_browser():
    try:
        from utils import browser
        browser.close()
        session = BASE_DIR / "utils" / "session.json"
        if session.exists():
            session.unlink()
    except Exception:
        pass


def _write_env(key: str, value: str):
    env_file = BASE_DIR / ".env"
    lines = []
    if env_file.exists():
        lines = env_file.read_text().splitlines()
    new_lines = [l for l in lines if not l.startswith(f"{key}=")]
    new_lines.append(f"{key}={value}")
    env_file.write_text("\n".join(new_lines) + "\n")
    os.environ[key] = value


# ── embedded HTML/CSS/JS ──────────────────────────────────────────────────────

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TUM Assistant</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --bg:        #0f0f0f;
  --surface:   #1a1a1a;
  --surface2:  #222222;
  --border:    #2e2e2e;
  --border2:   #3a3a3a;
  --text:      #e8e8e8;
  --muted:     #888;
  --accent:    #5B8BFF;
  --accent-d:  #3a6ae0;
  --success:   #3ecf8e;
  --warn:      #f5a623;
  --danger:    #e35b5b;
  --radius:    10px;
  --font:      'Instrument Sans', system-ui, sans-serif;
  --mono:      'DM Mono', monospace;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; font-family: var(--font); background: var(--bg); color: var(--text); font-size: 15px; line-height: 1.6; }

/* ── layout ── */
.app   { display: flex; height: 100vh; overflow: hidden; }
.sidebar { width: 220px; flex-shrink: 0; background: var(--surface); border-right: 1px solid var(--border); display: flex; flex-direction: column; padding: 0; }
.main  { flex: 1; overflow-y: auto; }
.panel { display: none; padding: 2rem 2.5rem; max-width: 780px; }
.panel.active { display: block; }

/* ── sidebar ── */
.brand { padding: 1.5rem 1.25rem 1rem; border-bottom: 1px solid var(--border); }
.brand h1 { font-size: 15px; font-weight: 600; letter-spacing: -0.01em; }
.brand span { font-size: 12px; color: var(--muted); font-family: var(--mono); }
.nav { padding: 0.75rem 0.5rem; flex: 1; }
.nav-item { display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-radius: 7px; cursor: pointer; font-size: 14px; color: var(--muted); transition: all 0.12s; border: none; background: none; width: 100%; text-align: left; }
.nav-item:hover { background: var(--surface2); color: var(--text); }
.nav-item.active { background: var(--surface2); color: var(--text); font-weight: 500; }
.nav-item .icon { width: 18px; height: 18px; opacity: 0.7; flex-shrink: 0; }
.nav-item.active .icon { opacity: 1; }
.nav-sep { height: 1px; background: var(--border); margin: 8px 12px; }
.session-badge { margin: auto 1rem 1rem; padding: 8px 10px; border-radius: 7px; font-size: 12px; font-family: var(--mono); display: flex; align-items: center; gap: 6px; }
.session-badge.ok  { background: rgba(62,207,142,0.1); color: var(--success); border: 1px solid rgba(62,207,142,0.2); }
.session-badge.bad { background: rgba(227,91,91,0.1);  color: var(--danger);  border: 1px solid rgba(227,91,91,0.2); }
.dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
.dot.ok  { background: var(--success); }
.dot.bad { background: var(--danger); }

/* ── panel header ── */
.panel-header { margin-bottom: 1.75rem; }
.panel-header h2 { font-size: 22px; font-weight: 600; letter-spacing: -0.02em; margin-bottom: 4px; }
.panel-header p  { font-size: 14px; color: var(--muted); }

/* ── cards ── */
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.25rem; margin-bottom: 1rem; }
.card-title { font-size: 11px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: var(--muted); margin-bottom: 1rem; }

/* ── forms ── */
.field  { margin-bottom: 1rem; }
.field:last-child { margin-bottom: 0; }
label { display: block; font-size: 13px; color: var(--muted); margin-bottom: 5px; font-weight: 500; }
input[type=text], input[type=password], input[type=date], input[type=number], select, textarea {
  width: 100%; padding: 9px 11px; background: var(--surface2); border: 1px solid var(--border2);
  border-radius: 7px; color: var(--text); font-size: 14px; font-family: var(--font);
  transition: border-color 0.12s; outline: none;
}
input:focus, select:focus, textarea:focus { border-color: var(--accent); }
textarea { resize: vertical; min-height: 90px; line-height: 1.5; }
select option { background: var(--surface2); }
.row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.row.trio { grid-template-columns: 1fr 1fr 1fr; }
.hint { font-size: 12px; color: var(--muted); margin-top: 4px; }

/* ── chips ── */
.chips { display: flex; gap: 7px; flex-wrap: wrap; margin-bottom: 1rem; }
.chip { padding: 5px 13px; font-size: 13px; border: 1px solid var(--border2); border-radius: 20px;
        cursor: pointer; color: var(--muted); background: transparent; transition: all 0.12s; font-family: var(--font); }
.chip:hover  { border-color: var(--border); color: var(--text); }
.chip.active { border-color: var(--accent); color: var(--accent); background: rgba(91,139,255,0.08); }

/* ── buttons ── */
.btn { padding: 9px 18px; border-radius: 7px; font-size: 14px; font-weight: 500; cursor: pointer; border: 1px solid var(--border2); background: var(--surface2); color: var(--text); font-family: var(--font); transition: all 0.12s; }
.btn:hover { border-color: var(--border); background: #2a2a2a; }
.btn:active { transform: scale(0.98); }
.btn-primary { background: var(--accent); border-color: var(--accent); color: #fff; }
.btn-primary:hover { background: var(--accent-d); border-color: var(--accent-d); }
.btn-success { background: rgba(62,207,142,0.15); border-color: rgba(62,207,142,0.3); color: var(--success); }
.btn-danger  { background: rgba(227,91,91,0.12); border-color: rgba(227,91,91,0.25); color: var(--danger); }
.btn-row { display: flex; gap: 8px; margin-top: 1rem; }

/* ── file drop ── */
.drop { border: 1px dashed var(--border2); border-radius: var(--radius); padding: 1.5rem; text-align: center; cursor: pointer; color: var(--muted); font-size: 13px; transition: all 0.15s; }
.drop:hover, .drop.over { border-color: var(--accent); color: var(--accent); background: rgba(91,139,255,0.04); }
.drop .file-name { color: var(--text); font-weight: 500; font-size: 14px; margin-top: 6px; }

/* ── toggle ── */
.toggle-row { display: flex; align-items: center; gap: 10px; }
.toggle { position: relative; width: 36px; height: 20px; flex-shrink: 0; }
.toggle input { opacity: 0; width: 0; height: 0; }
.toggle-track { position: absolute; inset: 0; background: var(--border2); border-radius: 20px; cursor: pointer; transition: background 0.15s; }
.toggle input:checked + .toggle-track { background: var(--accent); }
.toggle-track::after { content: ''; position: absolute; left: 3px; top: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; transition: transform 0.15s; }
.toggle input:checked + .toggle-track::after { transform: translateX(16px); }

/* ── toast ── */
#toast { position: fixed; bottom: 1.5rem; right: 1.5rem; background: var(--surface2); border: 1px solid var(--border2); border-radius: var(--radius); padding: 12px 18px; font-size: 14px; max-width: 360px; display: none; z-index: 999; box-shadow: 0 8px 32px rgba(0,0,0,0.4); }
#toast.ok   { border-color: rgba(62,207,142,0.4); color: var(--success); }
#toast.err  { border-color: rgba(227,91,91,0.4);  color: var(--danger); }
#toast.info { border-color: rgba(91,139,255,0.4); color: var(--accent); }

/* ── slide results ── */
.results { margin-top: 1rem; }
.result-item { background: var(--surface); border: 1px solid var(--border); border-radius: 7px; padding: 12px 14px; margin-bottom: 8px; display: flex; align-items: flex-start; gap: 12px; }
.result-score { font-family: var(--mono); font-size: 12px; color: var(--accent); flex-shrink: 0; padding-top: 2px; }
.result-meta  { font-size: 12px; color: var(--muted); margin-bottom: 4px; font-family: var(--mono); }
.result-text  { font-size: 13px; line-height: 1.5; }

/* ── setup wizard ── */
.setup-step { display: none; }
.setup-step.active { display: block; }
.step-indicator { display: flex; gap: 6px; margin-bottom: 1.5rem; }
.step-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--border2); }
.step-dot.done { background: var(--accent); }

/* ── misc ── */
.lock-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 100; }
.lock-box { background: var(--surface); border: 1px solid var(--border2); border-radius: 14px; padding: 2.5rem; max-width: 420px; text-align: center; }
.lock-box h2 { font-size: 20px; font-weight: 600; margin-bottom: 8px; }
.lock-box p  { color: var(--muted); font-size: 14px; margin-bottom: 1.5rem; }
.mono { font-family: var(--mono); font-size: 13px; color: var(--muted); }
</style>
</head>
<body>

<div id="lock-overlay" class="lock-overlay" style="display:none">
  <div class="lock-box">
    <div style="font-size:36px;margin-bottom:1rem">🔐</div>
    <h2>Setup required</h2>
    <p>Enter your TUM credentials once. They're stored securely in your system keychain — never in plaintext.</p>
    <button class="btn btn-primary" onclick="showPanel('setup');document.getElementById('lock-overlay').style.display='none'">
      Go to setup →
    </button>
  </div>
</div>

<div class="app">
  <!-- sidebar -->
  <aside class="sidebar">
    <div class="brand">
      <h1>TUM Assistant</h1>
      <span class="mono">v5 · local</span>
    </div>

    <nav class="nav">
      <button class="nav-item active" onclick="showPanel('message')" id="nav-message">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        Send message
      </button>
      <button class="nav-item" onclick="showPanel('homework')" id="nav-homework">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        Submit HW
      </button>
      <button class="nav-item" onclick="showPanel('slides')" id="nav-slides">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Find slide
      </button>
      <button class="nav-item" onclick="showPanel('room')" id="nav-room">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        Book room
      </button>
      <div class="nav-sep"></div>
      <button class="nav-item" onclick="showPanel('setup')" id="nav-setup">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>
        Settings
      </button>
    </nav>

    <div id="session-badge" class="session-badge bad">
      <span class="dot bad" id="dot"></span>
      <span id="session-label">not set up</span>
    </div>
  </aside>

  <!-- main area -->
  <main class="main">

    <!-- ── MESSAGE ── -->
    <div class="panel active" id="panel-message">
      <div class="panel-header">
        <h2>Send a message</h2>
        <p>Zulip DM, Zulip stream, Moodle forum post, or assignment comment</p>
      </div>

      <div class="card">
        <div class="card-title">destination</div>
        <div class="chips">
          <button class="chip active" onclick="setDest('dm',this)">Zulip DM</button>
          <button class="chip" onclick="setDest('stream',this)">Zulip stream</button>
          <button class="chip" onclick="setDest('forum',this)">Moodle forum</button>
          <button class="chip" onclick="setDest('assignment_comment',this)">Assignment comment</button>
        </div>

        <div id="d-dm">
          <div class="field">
            <label>Person</label>
            <input type="text" id="dm-person" placeholder="e.g. Dr. Müller, Ksusha Zimina — fuzzy matched">
          </div>
        </div>

        <div id="d-stream" style="display:none">
          <div class="row">
            <div class="field">
              <label>Stream</label>
              <input type="text" id="stream-name" list="streams-list" placeholder="e.g. algo-ws25">
              <datalist id="streams-list"></datalist>
            </div>
            <div class="field">
              <label>Topic</label>
              <input type="text" id="stream-topic" placeholder="e.g. HW3 question">
            </div>
          </div>
        </div>

        <div id="d-forum" style="display:none">
          <div class="row">
            <div class="field">
              <label>Course</label>
              <select id="forum-course"><option value="">— select —</option></select>
            </div>
            <div class="field">
              <label>Post title</label>
              <input type="text" id="forum-title" placeholder="e.g. Question about HW3 task 2">
            </div>
          </div>
        </div>

        <div id="d-assignment_comment" style="display:none">
          <div class="row">
            <div class="field">
              <label>Course</label>
              <select id="assign-course"><option value="">— select —</option></select>
            </div>
            <div class="field">
              <label>Assignment</label>
              <input type="text" id="assign-hw" placeholder="e.g. Sheet 4, HW3">
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">message</div>
        <div class="field">
          <textarea id="msg-body" rows="4" placeholder="Write your message..."></textarea>
        </div>
        <div class="field">
          <label>Attachment (optional)</label>
          <div class="drop" id="msg-drop" onclick="document.getElementById('msg-file').click()"
               ondragover="ev(event,'msg-drop')" ondragleave="el('msg-drop')" ondrop="df(event,'msg-drop','msg-fname','msg-file-obj')">
            drop a file or click to browse
            <div class="file-name" id="msg-fname"></div>
          </div>
          <input type="file" id="msg-file" style="display:none" onchange="sf('msg-file','msg-fname')">
        </div>
      </div>

      <button class="btn btn-primary" onclick="sendMessage()" style="width:100%">Send →</button>
    </div>


    <!-- ── HOMEWORK ── -->
    <div class="panel" id="panel-homework">
      <div class="panel-header">
        <h2>Submit homework</h2>
        <p>Auto-generates Deckblatt, merges, compresses if needed, uploads to TUM Online</p>
      </div>

      <div class="card">
        <div class="card-title">details</div>
        <div class="row">
          <div class="field">
            <label>Course</label>
            <select id="hw-course"><option value="">— select —</option></select>
          </div>
          <div class="field">
            <label>Sheet / assignment</label>
            <input type="text" id="hw-sheet" placeholder="e.g. Sheet 4">
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">your pdf</div>
        <div class="drop" id="hw-drop" onclick="document.getElementById('hw-file').click()"
             ondragover="ev(event,'hw-drop')" ondragleave="el('hw-drop')" ondrop="df(event,'hw-drop','hw-fname','hw-file-obj')">
          drop your homework PDF here
          <div class="file-name" id="hw-fname"></div>
        </div>
        <input type="file" id="hw-file" accept=".pdf" style="display:none" onchange="sf('hw-file','hw-fname')">
      </div>

      <div class="card">
        <div class="card-title">options</div>
        <div class="field toggle-row" style="margin-bottom:1rem">
          <label class="toggle">
            <input type="checkbox" id="hw-deckblatt" checked>
            <span class="toggle-track"></span>
          </label>
          <span style="font-size:14px">Auto-generate Deckblatt (cover page)</span>
        </div>
        <div class="field">
          <label>Max file size (KB)</label>
          <input type="number" id="hw-maxsize" value="8000" style="width:140px">
          <div class="hint">File is compressed with Ghostscript if larger</div>
        </div>
      </div>

      <button class="btn btn-primary" onclick="submitHw()" style="width:100%">Submit homework →</button>
    </div>


    <!-- ── SLIDES ── -->
    <div class="panel" id="panel-slides">
      <div class="panel-header">
        <h2>Find a slide</h2>
        <p>Semantic search across all indexed lecture PDFs (nomic-embed-text + HNSW)</p>
      </div>

      <div class="card">
        <div class="card-title">search</div>
        <div class="field" style="display:flex;gap:8px;align-items:flex-end;margin-bottom:0">
          <div style="flex:1">
            <label>What are you looking for?</label>
            <input type="text" id="slide-query" placeholder="e.g. master theorem, Markov chains convergence..." onkeydown="if(event.key==='Enter')searchSlides()">
          </div>
          <button class="btn btn-primary" onclick="searchSlides()" style="flex-shrink:0">Search</button>
        </div>
      </div>

      <div id="slide-results" class="results"></div>

      <div class="card" style="margin-top:1rem">
        <div class="card-title">index a new lecture pdf</div>
        <div class="drop" id="idx-drop" onclick="document.getElementById('idx-file').click()"
             ondragover="ev(event,'idx-drop')" ondragleave="el('idx-drop')" ondrop="df(event,'idx-drop','idx-fname','idx-file-obj')">
          drop a lecture PDF to add it to the index
          <div class="file-name" id="idx-fname"></div>
        </div>
        <input type="file" id="idx-file" accept=".pdf" style="display:none" onchange="sf('idx-file','idx-fname')">
        <div class="btn-row">
          <button class="btn" onclick="indexPdf()">Index PDF</button>
        </div>
      </div>
    </div>


    <!-- ── ROOM ── -->
    <div class="panel" id="panel-room">
      <div class="panel-header">
        <h2>Book a library room</h2>
        <p>Searches available slots on TUM Online and confirms the booking</p>
      </div>

      <div class="card">
        <div class="card-title">booking details</div>
        <div class="row">
          <div class="field">
            <label>Date</label>
            <input type="date" id="room-date">
          </div>
          <div class="field">
            <label>Duration</label>
            <select id="room-dur">
              <option value="1">1 hour</option>
              <option value="2" selected>2 hours</option>
              <option value="3">3 hours</option>
              <option value="4">4 hours</option>
            </select>
          </div>
        </div>
        <div class="field">
          <label>Building filter (optional)</label>
          <input type="text" id="room-building" placeholder="e.g. Stammgelände, Garching">
        </div>
      </div>

      <button class="btn btn-primary" onclick="bookRoom()" style="width:100%">Book room →</button>
    </div>


    <!-- ── SETUP ── -->
    <div class="panel" id="panel-setup">
      <div class="panel-header">
        <h2>Settings</h2>
        <p>Credentials are stored once in your system keychain (macOS Keychain / libsecret / Credential Manager)</p>
      </div>

      <div class="card">
        <div class="card-title">TUM account</div>
        <div class="row">
          <div class="field">
            <label>TUM ID</label>
            <input type="text" id="s-tum-user" placeholder="e.g. ge12abc">
          </div>
          <div class="field">
            <label>TUM password</label>
            <input type="password" id="s-tum-pass" placeholder="leave blank to keep existing">
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Zulip</div>
        <div class="field">
          <label>Zulip server URL</label>
          <input type="text" id="s-zulip-site" placeholder="https://zulip.cit.tum.de">
        </div>
        <div class="row">
          <div class="field">
            <label>Zulip email</label>
            <input type="text" id="s-zulip-email" placeholder="yourname@tum.de">
          </div>
          <div class="field">
            <label>Zulip API key</label>
            <input type="password" id="s-zulip-key" placeholder="leave blank to keep existing">
            <div class="hint">Settings → Personal settings → API key</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Student info (for Deckblatt cover pages)</div>
        <div class="row">
          <div class="field">
            <label>Full name</label>
            <input type="text" id="s-name" placeholder="Vorname Nachname">
          </div>
          <div class="field">
            <label>Matrikelnummer</label>
            <input type="text" id="s-matrikel" placeholder="03XXXXXX">
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Gemini API key (for natural language parsing)</div>
        <div class="field">
          <input type="password" id="s-gemini" placeholder="AIza... — leave blank to keep existing">
          <div class="hint">Get yours at <a href="https://aistudio.google.com" target="_blank" style="color:var(--accent)">aistudio.google.com</a></div>
        </div>
      </div>

      <div class="btn-row">
        <button class="btn btn-primary" onclick="saveSetup()" style="flex:1">Save credentials</button>
        <button class="btn" onclick="runCrawl()">Re-crawl courses</button>
      </div>
    </div>

  </main>
</div>

<div id="toast"></div>

<script>
// ── state ──────────────────────────────────────────────────────────────────
let dest = 'dm';
const fileObjects = {};

// ── init ───────────────────────────────────────────────────────────────────
async function init() {
  await checkStatus();
  await loadCourses();
  await loadStreams();
  loadProfile();
  document.getElementById('room-date').value = new Date().toISOString().slice(0,10);
}

async function checkStatus() {
  const r = await fetch('/api/status').then(r=>r.json());
  const badge = document.getElementById('session-badge');
  const dot   = document.getElementById('dot');
  const label = document.getElementById('session-label');
  const overlay = document.getElementById('lock-overlay');
  if (r.registered) {
    badge.className = 'session-badge ok';
    dot.className   = 'dot ok';
    label.textContent = 'logged in';
    overlay.style.display = 'none';
  } else {
    badge.className = 'session-badge bad';
    dot.className   = 'dot bad';
    label.textContent = 'not set up';
    overlay.style.display = 'flex';
  }
  return r.registered;
}

async function loadCourses() {
  const courses = await fetch('/api/courses').then(r=>r.json()).catch(()=>[]);
  ['forum-course','assign-course','hw-course'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">— select —</option>';
    courses.forEach(c => {
      const o = document.createElement('option');
      o.value = o.textContent = c;
      sel.appendChild(o);
    });
  });
}

async function loadStreams() {
  const streams = await fetch('/api/zulip/streams').then(r=>r.json()).catch(()=>[]);
  const dl = document.getElementById('streams-list');
  if (!dl) return;
  dl.innerHTML = '';
  streams.forEach(s => {
    const o = document.createElement('option');
    o.value = s;
    dl.appendChild(o);
  });
}

async function loadProfile() {
  const p = await fetch('/api/profile').then(r=>r.json()).catch(()=>({}));
  if (p.tum_user)       document.getElementById('s-tum-user').value    = p.tum_user;
  if (p.zulip_site)     document.getElementById('s-zulip-site').value  = p.zulip_site;
  if (p.zulip_email)    document.getElementById('s-zulip-email').value = p.zulip_email;
  if (p.student_name)   document.getElementById('s-name').value        = p.student_name;
  if (p.matrikelnummer) document.getElementById('s-matrikel').value    = p.matrikelnummer;
}

// ── navigation ──────────────────────────────────────────────────────────────
function showPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  document.getElementById('nav-' + name).classList.add('active');
}

// ── destination switcher ────────────────────────────────────────────────────
function setDest(d, el) {
  dest = d;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  ['dm','stream','forum','assignment_comment'].forEach(k => {
    document.getElementById('d-' + k).style.display = k === d ? 'block' : 'none';
  });
}

// ── file helpers ─────────────────────────────────────────────────────────────
function sf(inputId, nameId) {
  const f = document.getElementById(inputId).files[0];
  document.getElementById(nameId).textContent = f ? f.name : '';
  fileObjects[nameId] = f || null;
}
function ev(e, id) { e.preventDefault(); document.getElementById(id).classList.add('over'); }
function el(id) { document.getElementById(id).classList.remove('over'); }
function df(e, dropId, nameId, key) {
  e.preventDefault();
  document.getElementById(dropId).classList.remove('over');
  const f = e.dataTransfer.files[0];
  if (f) { document.getElementById(nameId).textContent = f.name; fileObjects[nameId] = f; }
}

// ── toast ───────────────────────────────────────────────────────────────────
let toastTimer;
function toast(msg, type='info') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = type;
  t.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.style.display = 'none', 4000);
}

// ── send message ─────────────────────────────────────────────────────────────
async function sendMessage() {
  const body = document.getElementById('msg-body').value.trim();
  if (!body) { toast('Write a message first', 'err'); return; }

  const payload = { dest_type: dest, message: body };

  if (dest === 'dm') {
    payload.person = document.getElementById('dm-person').value.trim();
    if (!payload.person) { toast('Enter a person name', 'err'); return; }
  } else if (dest === 'stream') {
    payload.stream = document.getElementById('stream-name').value.trim();
    payload.topic  = document.getElementById('stream-topic').value.trim() || 'General';
    if (!payload.stream) { toast('Enter a stream name', 'err'); return; }
  } else if (dest === 'forum') {
    payload.course = document.getElementById('forum-course').value;
    if (!payload.course) { toast('Select a course', 'err'); return; }
  } else if (dest === 'assignment_comment') {
    payload.course     = document.getElementById('assign-course').value;
    payload.assignment = document.getElementById('assign-hw').value.trim();
    if (!payload.course) { toast('Select a course', 'err'); return; }
  }

  // Attachment: for now just pass the file name (server-side upload would need multipart)
  const file = fileObjects['msg-fname'];
  if (file) payload.attachment = file.name;

  const r = await fetch('/api/send', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  }).then(r=>r.json());
  toast(r.message || (r.ok ? 'Sent!' : r.error), r.ok ? 'ok' : 'err');
}

// ── submit homework ──────────────────────────────────────────────────────────
async function submitHw() {
  const course = document.getElementById('hw-course').value;
  const sheet  = document.getElementById('hw-sheet').value.trim();
  const file   = fileObjects['hw-fname'];
  if (!course || !sheet || !file) { toast('Fill in course, sheet, and drop a PDF', 'err'); return; }

  const fd = new FormData();
  fd.append('course', course);
  fd.append('sheet', sheet);
  fd.append('hw_pdf', file);
  fd.append('add_deckblatt', document.getElementById('hw-deckblatt').checked);
  fd.append('max_size_kb', document.getElementById('hw-maxsize').value);

  const r = await fetch('/api/submit_hw', { method:'POST', body: fd }).then(r=>r.json());
  toast(r.message || (r.ok ? 'Submission started!' : r.error), r.ok ? 'ok' : 'err');
}

// ── slide search ─────────────────────────────────────────────────────────────
async function searchSlides() {
  const q = document.getElementById('slide-query').value.trim();
  if (!q) return;
  const container = document.getElementById('slide-results');
  container.innerHTML = '<p style="color:var(--muted);font-size:13px;padding:8px 0">Searching...</p>';
  const results = await fetch(`/api/slide/search?q=${encodeURIComponent(q)}&k=8`).then(r=>r.json());
  if (!Array.isArray(results) || results.length === 0) {
    container.innerHTML = '<p style="color:var(--muted);font-size:13px;padding:8px 0">No results — make sure you\'ve indexed some PDFs first.</p>';
    return;
  }
  container.innerHTML = results.map(h => `
    <div class="result-item">
      <div class="result-score">${(h.score*100).toFixed(0)}%</div>
      <div>
        <div class="result-meta">${h.pdf} · page ${h.page_num}</div>
        <div class="result-text">${h.text ? h.text.slice(0,200).replace(/</g,'&lt;') + '…' : ''}</div>
      </div>
    </div>`).join('');
}

async function indexPdf() {
  const file = fileObjects['idx-fname'];
  if (!file) { toast('Drop a PDF first', 'err'); return; }
  const fd = new FormData();
  fd.append('pdf', file);
  const r = await fetch('/api/slide/index', { method:'POST', body: fd }).then(r=>r.json());
  toast(r.message || (r.ok ? 'Indexing started!' : r.error), r.ok ? 'info' : 'err');
}

// ── room booking ─────────────────────────────────────────────────────────────
async function bookRoom() {
  const date = document.getElementById('room-date').value;
  if (!date) { toast('Pick a date', 'err'); return; }
  const r = await fetch('/api/book_room', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      date,
      duration: document.getElementById('room-dur').value,
      building: document.getElementById('room-building').value.trim() || null
    })
  }).then(r=>r.json());
  toast(r.message || (r.ok ? 'Booking started!' : r.error), r.ok ? 'ok' : 'err');
}

// ── setup ─────────────────────────────────────────────────────────────────────
async function saveSetup() {
  const payload = {
    tum_user:       document.getElementById('s-tum-user').value.trim(),
    tum_password:   document.getElementById('s-tum-pass').value,
    zulip_site:     document.getElementById('s-zulip-site').value.trim(),
    zulip_email:    document.getElementById('s-zulip-email').value.trim(),
    zulip_api_key:  document.getElementById('s-zulip-key').value,
    student_name:   document.getElementById('s-name').value.trim(),
    matrikelnummer: document.getElementById('s-matrikel').value.trim(),
    gemini_api_key: document.getElementById('s-gemini').value,
  };
  if (!payload.tum_user || !payload.zulip_email || !payload.student_name || !payload.matrikelnummer) {
    toast('Fill in TUM ID, Zulip email, name, and Matrikelnummer', 'err'); return;
  }
  const r = await fetch('/api/setup', {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
  }).then(r=>r.json());
  if (r.ok) {
    document.getElementById('s-tum-pass').value = '';
    document.getElementById('s-zulip-key').value = '';
    document.getElementById('s-gemini').value = '';
    const ok = await checkStatus();
    if (ok) {
      toast('All set! Credentials saved securely.', 'ok');
      showPanel('message');
    } else {
      toast('Saved — but status check still shows not registered. Check terminal.', 'info');
    }
  } else {
    toast(r.error || 'Error saving', 'err');
  }
}

async function runCrawl() {
  toast('Crawling Moodle, TUM Online, Zulip — check terminal for progress', 'info');
  await fetch('/api/crawl', { method:'POST' });
  setTimeout(() => { loadCourses(); loadStreams(); }, 3000);
}

init();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n" + "─"*50)
    print("  TUM Assistant GUI")
    print("  Open: http://localhost:5678")
    print("─"*50 + "\n")
    app.run(host="127.0.0.1", port=5678, debug=False, threaded=True)
