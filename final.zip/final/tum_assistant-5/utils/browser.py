"""
utils/browser.py — shared Playwright session with TUM SSO login.

Session cookies are saved to disk after every successful login.
On the next run the saved session is restored, so login only happens
once (or when the session expires, typically after several weeks).
"""
from playwright.sync_api import sync_playwright, BrowserContext, Page
from pathlib import Path

HEADLESS     = False                              # set True for fully headless operation
SESSION_FILE = Path(__file__).parent / "session.json"

_playwright = None
_browser    = None
_context: BrowserContext | None = None


def get_context() -> BrowserContext:
    global _playwright, _browser, _context
    if _context is not None:
        return _context

    from config import TUM_USERNAME, TUM_PASSWORD, MOODLE_BASE

    _playwright = sync_playwright().start()
    _browser = _playwright.chromium.launch(
        headless=HEADLESS,
        args=["--new-window", "--force-app-mode"],
    )

    # ── try to restore saved session ─────────────────────────────────────────
    if SESSION_FILE.exists():
        print("[auth] Restoring saved browser session...")
        _context = _browser.new_context(storage_state=str(SESSION_FILE))
        page = _context.new_page()
        page.goto(f"{MOODLE_BASE}/my/", wait_until="networkidle", timeout=30_000)
        if "moodle.tum.de" in page.url and "login" not in page.url:
            print("[auth] ✓ Session valid — skipping login")
            page.close()
            return _context
        print("[auth] Saved session expired — logging in again...")
        page.close()
        _context.close()
        _context = None

    # ── fresh login ───────────────────────────────────────────────────────────
    _context = _browser.new_context()
    _login_moodle(_context.new_page(), TUM_USERNAME, TUM_PASSWORD, MOODLE_BASE)
    return _context


def _login_moodle(page: Page, username: str, password: str, moodle_base: str):
    """Log in via TUM Shibboleth SSO and persist the session to disk."""
    print("[auth] Navigating to TUM SSO...")
    bypass_url = (
        "https://www.moodle.tum.de/Shibboleth.sso/Login?"
        "providerId=https%3A%2F%2Ftumidp.lrz.de%2Fidp%2Fshibboleth&"
        "target=https%3A%2F%2Fwww.moodle.tum.de%2Fauth%2Fshibboleth%2Findex.php"
    )
    page.goto(bypass_url, wait_until="domcontentloaded", timeout=60_000)
    page.wait_for_load_state("networkidle")

    if "login.tum.de" in page.url:
        print("[auth] TUM login page — entering credentials...")
        page.fill("input[name='j_username']", username)
        page.fill("input[name='j_password']", password)
        page.click("button[name='_eventId_proceed'], button[type='submit']")
        page.wait_for_load_state("networkidle", timeout=60_000)

    if "moodle.tum.de" not in page.url:
        page.screenshot(path=str(Path(__file__).parent / "login_debug_failed.png"))
        raise RuntimeError(
            f"[auth] Login failed — ended up at: {page.url}\n"
            "Screenshot saved to utils/login_debug_failed.png"
        )

    print("[auth] ✓ Logged into Moodle — saving session cookies...")
    page.context.storage_state(path=str(SESSION_FILE))
    SESSION_FILE.chmod(0o600)
    page.close()


def new_page() -> Page:
    """Open a new tab inside the persistent authenticated context."""
    return get_context().new_page()


def close():
    """Tear down the browser. Called when credentials change."""
    global _playwright, _browser, _context
    if _context:
        try: _context.close()
        except Exception: pass
    if _browser:
        try: _browser.close()
        except Exception: pass
    if _playwright:
        try: _playwright.stop()
        except Exception: pass
    _context = _browser = _playwright = None
